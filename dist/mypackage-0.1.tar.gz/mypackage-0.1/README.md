This is just a preliminary package I have made to test out the process of making packages.

#building this package locally 'python setup.py sdist'

installing this package from GitHub
pip install git+https://github.com/IvorPietersen/mypackage.git

updating this package from GithHub
pip install --upgrade git+https://github.com/IvorPietersen/mypackage.git
